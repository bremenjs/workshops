/*!
 * Bremen.js - Workshop #1
 *
 * Photoframe
 *
 * Copyright(c) 2012 Bremen, Germany
 *
 * Authors:
 *
 *     Wer? Bitte eintragen ;)
 *
 * MIT Licensed
 *
 */

"use strict";

// Die "main" Methode.
(function () {

}());